package hod.response.parser;

/**
 * Created by vanphongvu on 12/7/15.
 */
public class DeleteQueryProfileResponse {
    public String message; //(string )  Indicates that the query profile was deleted successfully.
    public String query_profile; //(string )  The name of the query profile.
}
