package hod.response.parser;

/**
 * Created by vanphongvu on 12/7/15.
 */
public class CancelConnectorResponse {
    public String connector;
    public Boolean stopped_schedule;
}
