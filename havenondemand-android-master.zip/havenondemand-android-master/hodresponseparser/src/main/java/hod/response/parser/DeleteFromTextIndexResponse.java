package hod.response.parser;

/**
 * Created by vanphongvu on 12/7/15.
 */
public class DeleteFromTextIndexResponse {
    public int documents_deleted; // ( integer )  The number of deleted documents.
    public String index; // ( string )  The index the document was deleted from.
}
