package hod.response.parser;

/**
 * Created by vanphongvu on 12/7/15.
 */
public class UpdateQueryProfileResponse {
    public String message; //(string )  Indicates that the profile was updated.
    public String query_profile; //(string )  Query profile name.
}
