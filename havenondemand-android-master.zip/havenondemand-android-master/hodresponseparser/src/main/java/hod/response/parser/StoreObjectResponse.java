package hod.response.parser;

/**
 * Created by vanphongvu on 12/7/15.
 */
public class StoreObjectResponse {
    public String reference; // The object store reference of the extracted file.
}
