package hod.response.parser;

/**
 * Created by vanphongvu on 12/7/15.
 */
public class ViewDocumentResponse {
    public String document; // The Base 64 encoded HTML version of the document, if rawhtml is set to false.
}
