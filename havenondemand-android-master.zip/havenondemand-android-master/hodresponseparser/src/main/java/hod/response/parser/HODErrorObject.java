package hod.response.parser;

/**
 * Created by vanphongvu on 1/5/16.
 */
public class HODErrorObject {
    public int error = 0;
    public String reason = "";
    public String detail = "";
    public String jobID = "";
}
