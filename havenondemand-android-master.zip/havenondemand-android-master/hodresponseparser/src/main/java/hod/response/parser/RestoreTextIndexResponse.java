package hod.response.parser;

/**
 * Created by vanphongvu on 12/7/15.
 */
public class RestoreTextIndexResponse {
    public String restored; //(string , optional)  The name of the index created.
}
