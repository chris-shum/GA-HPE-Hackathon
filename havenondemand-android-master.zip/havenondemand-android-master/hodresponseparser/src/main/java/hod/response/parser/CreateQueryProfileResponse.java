package hod.response.parser;

/**
 * Created by vanphongvu on 12/7/15.
 */
public class CreateQueryProfileResponse {
    public String message; //( string )  Indicates that the query profile was created.
    public String query_profile; // ( string )  Query profile name.
}
