package hod.response.parser;

/**
 * Created by vanphongvu on 12/7/15.
 */
public class StartConnectorResponse {
    public String connector; // The name of the connector.
    public String token;
}
