package hod.response.parser;

/**
 * Created by vanphongvu on 12/7/15.
 */
public class CreateTextIndexResponse {
    public String index; //(string , optional)  The name of the new index.
    public String message; //( string , optional)  Indicates that the index was created.
}
