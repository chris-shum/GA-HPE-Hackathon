package hod.response.parser;

/**
 * Created by vanphongvu on 12/7/15.
 */
public class HighlightTextResponse {
    public String text;
}
