package hod.response.parser;

import java.util.List;

/**
 * Created by vanphongvu on 12/7/15.
 */
public class AutoCompleteResponse {
    public List<String> words;
}
