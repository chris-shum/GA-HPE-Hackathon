package hod.response.parser;

/**
 * Created by vanphongvu on 12/7/15.
 */
public class TrainPredictionResponse {
    public String message; //( string )  A message that contains the status of the service.
    public String service; //( string )  The name that identifies the service that has been created.
}
